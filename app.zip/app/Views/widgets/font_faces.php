<style>
    @font-face {
        font-family: "Flaticon";
        src: url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon.eot");
        src: url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon-.eot#iefix") format("embedded-opentype"), url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon.woff") format("woff"), url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon.ttf") format("truetype"), url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon.svg#Flaticon") format("svg");
        font-weight: normal;
        font-style: normal
    }

    @media screen and (-webkit-min-device-pixel-ratio:0) {
        @font-face {
            font-family: "Flaticon";
            src: url("<?=base_url()?>/public/fonts/flaticon/font/Flaticon.svg#Flaticon") format("svg")
        }
    }
    <?php
    //@font-face {*/
    /*    font-family: 'FontAwesome';*/
    /*    src: url('*///=base_url()/*/public/fonts/fontawesome-webfont.eot?v=4.7.0');*/
    /*    src: url('*///=base_url()/*/public/fonts/fontawesome-webfont.eot?#iefix&v=4.7.0') format('embedded-opentype'), url('*///=base_url()/*/public/fonts/fontawesome-webfont.woff2?v=4.7.0') format('woff2'), url('*///=base_url()/*/public/fonts/fontawesome-webfont.woff?v=4.7.0') format('woff'), url('*///=base_url()/*/public/fonts/fontawesome-webfont.ttf?v=4.7.0') format('truetype'), url('*///=base_url()/*/public/fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular') format('svg');*/
    /*    font-weight: normal;*/
    /*    font-style: normal*/
    /*}*/
    /**/
    /*@font-face {*/
    /*    font-family: "Ionicons";*/
    /*    src: url("*///=base_url()/*/public/fonts/ionicons.eot?v=4.5.5");*/
    /*    src: url("*///=base_url()/*/public/fonts/ionicons.eot?v=4.5.5#iefix") format("embedded-opentype"), url("*///=base_url()/*/public/fonts/ionicons.woff2?v=4.5.5") format("woff2"), url("*///=base_url()/*/public/fonts/ionicons.woff?v=4.5.5") format("woff"), url("*///=base_url()/*/public/fonts/ionicons.ttf?v=4.5.5") format("truetype"), url("*///=base_url()/*/public/fonts/ionicons.svg?v=4.5.5#Ionicons") format("svg");*/
    /*    font-weight: normal;*/
    /*    font-style: normal*/
    /*}*/
    ?>


</style>